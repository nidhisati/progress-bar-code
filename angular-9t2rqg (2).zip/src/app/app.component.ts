import { Component} from '@angular/core';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent{
  name = 'Angular';
  buttons = [29,11,-5,-25];
  bars = [84,48,88];
  limit = 130;
  selectedProgressBar;
  maxWidthColor;
  changeSelection(e){
    let changedProgressBar = e.target.value;
    this.selectedProgressBar = changedProgressBar;
  }

  changeValue(value){
    let selectedProgressBar = (this.selectedProgressBar) ? this.selectedProgressBar : 0;
    let currentValue = this.bars[selectedProgressBar];
    let newValue = (currentValue + value > 0) ? currentValue + value : 0;
    this.bars[selectedProgressBar] = newValue;
  }
}